# Geek
Lançamentos da cultura geek
scrummaster: Ana Clara Maximino
mebros:
Arthur Aguiar
Henrique Rodrigues
Isabela Guessi

